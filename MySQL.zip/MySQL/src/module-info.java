module MySQL {
	requires java.sql;
}