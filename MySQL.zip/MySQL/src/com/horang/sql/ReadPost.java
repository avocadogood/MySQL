package com.horang.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ReadPost {
	public static void rp(Connection con, Scanner sc) {
        Statement st = null;
        System.out.print("조회할 글의 번호를 입력하세요: ");
        String readNo = sc.next();
        sc.nextLine();

        try {
            st = con.createStatement();
            ResultSet result = st.executeQuery("select * from board where b_no ="+readNo);
            if (result.next()) {
                String title = result.getString("b_title");
                String text = result.getString("b_text");
                String id = result.getString("b_id");
                System.out.println("글 제목: " + title);
                System.out.println("글 작성자: " + id);
                System.out.println("글 내용: " + text);
            } else {
                System.out.println("입력한 글 번호가 존재하지 않습니다.");
            }
            st.close();
        } catch (SQLException e) {
            System.out.println("글 조회 중 오류가 발생하였습니다.");
            e.printStackTrace();
        }
    }

}
