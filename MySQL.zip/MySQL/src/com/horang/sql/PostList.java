package com.horang.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PostList {
	
	public static void pl(Connection con) {
        try {
            Statement st = con.createStatement();
            String sql = "select * from board";
            ResultSet result = st.executeQuery(sql);
            System.out.println("글 리스트: ");
            while (result.next()) {
                int no = result.getInt("b_no");
                String title = result.getString("b_title");
                String id = result.getString("b_id");
                String datetime = result.getString("b_datetime");
                int hit = result.getInt("b_hit");

                System.out.println("글 번호: " + no);
                System.out.println("글 제목: " + title);
                System.out.println("작성자: " + id);
                System.out.println("작성 일시: " + datetime);
                System.out.println("조회수: " + hit);
            }
            st.close();
        } catch (SQLException e) {
            System.out.println("글 리스트를 가져오는 중 오류가 발생하였습니다.");
            e.printStackTrace();
        }
    }

}
