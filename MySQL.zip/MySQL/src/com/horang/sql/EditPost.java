package com.horang.sql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EditPost {
	public static void ep(Connection con, Scanner sc) {
	    System.out.print("수정할 글의 번호를 입력하세요: ");
	    String postNo = sc.next();
	    sc.nextLine();

	    try {
	        Statement st = con.createStatement();
	        String sql = "select * from board where b_no = " + postNo;
	        ResultSet result = st.executeQuery(sql);
	        if (result.next()) {
	            String title = result.getString("b_title");
	            String text = result.getString("b_text");

	            System.out.println("현재 제목: " + title);
	            System.out.println("현재 내용: " + text);
	            System.out.print("수정할 제목을 입력하세요: ");
	            String newTitle = sc.nextLine();
	            System.out.print("수정할 내용을 입력하세요: ");
	            String newText = sc.nextLine();

	            sql = "update board set b_title = '" + newTitle + "', b_text = '" + newText + "' where b_no = " + postNo;
	            int resultCount = st.executeUpdate(sql);
	            if (resultCount > 0) {
	                System.out.println("글이 성공적으로 수정되었습니다.");
	            } else {
	                System.out.println("수정할 글을 찾지 못하였습니다.");
	            }
	        } else {
	            System.out.println("수정할 글을 찾지 못하였습니다.");
	        }
	        st.close();
	    } catch (SQLException e) {
	        System.out.println("글 수정 중 오류가 발생하였습니다.");
	        e.printStackTrace();
	    }
	}

}
