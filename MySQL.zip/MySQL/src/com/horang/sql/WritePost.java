package com.horang.sql;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class WritePost {
	
    public static void wp(Connection con, Scanner sc) {
    	sc.nextLine();
        System.out.println("글 제목을 입력하세요: ");
        String title = sc.nextLine();
        System.out.println("작성자 ID를 입력하세요: ");
        String id = sc.nextLine();
        System.out.print("글 내용을 입력하세요: ");
        String text = sc.next();

        try {
            Statement st = con.createStatement();
            String sql = "insert into board (b_title, b_id, b_datetime, b_text) VALUES ('" + title + "', '" + id + "',now(), '" + text + "')";
            int resultCount = st.executeUpdate(sql);
            if (resultCount > 0) {
                System.out.println("글이 성공적으로 등록되었습니다.");
            } else {
                System.out.println("글 등록에 실패하였습니다.");
            }
        } catch (SQLException e) {
            System.out.println("글 게시 중 오류가 발생하였습니다.");
            e.printStackTrace();
        }
    }
}
